function showAlert() {
    alert('Im subhan (fa20-bcs-063)');
}
function doBindings() {
    showAlert();
}

window.onload(doBindings)

